package com.abm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abm.entity.User;
import com.abm.repository.UserRepository;
import com.abm.service.UserService;

@RestController
public class UserLogin {
	
	/*
	 * @RequestMapping("/login") public String home() {
	 * System.out.println("this is home page"); return "success"; }
	 */
	
	@Autowired
	private UserService userService;
	
	 @RequestMapping("/login") 
	 public String loginVerification(@RequestBody User user) {
		 
		 boolean verified = userService.verifyUser(user.getEmail(), user.getPassword());
		 
		 if(verified) {
			 return "success";
		 }
		 else {
			 return "failure";
		 }
		 
	 }
	

}
