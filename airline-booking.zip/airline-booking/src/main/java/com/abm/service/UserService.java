
  package com.abm.service;
  
  import javax.transaction.Transactional;
  
  import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abm.repository.UserRepository;
  
  
  @Transactional 
  @Service
  public class UserService {
  
  @Autowired UserRepository userRepo;
  
  public boolean verifyUser(String email, String password) {
  
  long count = userRepo.verifyByEmailPass(email, password); // 1
  
  if( count == 1L) { return true; } else {
	  return false;
	  }
  
  
  }
  
  }
  
 