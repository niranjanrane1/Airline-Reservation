package com.abm.repository;

import org.springframework.data.repository.CrudRepository;

import com.abm.entity.Cancelation;

public interface CancelationRepository extends CrudRepository<Cancelation, Integer>{

}
