package com.abm.repository;

import org.springframework.data.repository.CrudRepository;

import com.abm.entity.Seat;

public interface SeatRepository extends CrudRepository<Seat, Integer>{

}
