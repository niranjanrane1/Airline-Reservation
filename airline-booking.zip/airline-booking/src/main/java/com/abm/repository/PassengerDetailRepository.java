package com.abm.repository;

import org.springframework.data.repository.CrudRepository;

import com.abm.entity.PassengerDetail;

public interface PassengerDetailRepository extends CrudRepository<PassengerDetail, Integer>{

}
