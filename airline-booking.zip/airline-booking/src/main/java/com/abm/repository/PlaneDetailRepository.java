package com.abm.repository;

import org.springframework.data.repository.CrudRepository;

import com.abm.entity.PlaneDetail;

public interface PlaneDetailRepository extends CrudRepository<PlaneDetail, Integer>{

}
