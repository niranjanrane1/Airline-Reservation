package com.abm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlineBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirlineBookingApplication.class, args);
		
	}

}
